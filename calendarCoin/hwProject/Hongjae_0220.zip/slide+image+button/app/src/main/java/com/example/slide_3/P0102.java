package com.example.slide_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class P0102 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p0102);
    }
}
